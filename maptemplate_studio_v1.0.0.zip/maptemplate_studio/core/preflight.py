"""
Cartographic Preflight Quality Control Engine for MapTemplate Studio.
Evaluates layouts and configurations against professional cartographic rules.
Categorizes findings into PASS, WARNING, and BLOCK, providing remediation guidance.
"""

import os
from typing import Dict, Any, List, Optional
from dataclasses import dataclass, field


@dataclass
class PreflightIssue:
    severity: str  # 'BLOCK', 'WARNING', 'PASS'
    code: str
    title: str
    detail: str
    remediation: str


@dataclass
class PreflightReport:
    passed: bool
    score: int  # 0-100%
    issues: List[PreflightIssue] = field(default_factory=list)

    @property
    def has_blockers(self) -> bool:
        return any(i.severity == "BLOCK" for i in self.issues)

    @property
    def warning_count(self) -> int:
        return sum(1 for i in self.issues if i.severity == "WARNING")

    @property
    def pass_count(self) -> int:
        return sum(1 for i in self.issues if i.severity == "PASS")


class PreflightChecker:
    """Performs preflight checks on project data, layout structure, and cartographic marginalia."""

    @classmethod
    def evaluate(
        cls,
        layout=None,
        template_manifest: Optional[Dict[str, Any]] = None,
        role_layers: Optional[Dict[str, List[Any]]] = None,
        role_extents: Optional[Dict[str, Any]] = None,
        metadata: Optional[Dict[str, str]] = None,
        export_path: Optional[str] = None,
        logo_path: Optional[str] = None,
    ) -> PreflightReport:
        issues: List[PreflightIssue] = []
        score = 100
        metadata = metadata or {}
        role_layers = role_layers or {}
        role_extents = role_extents or {}

        # 1. Structural Integrity Check
        if layout is not None and hasattr(layout, "items"):
            # Check for presence of map items on instantiated layout
            map_items = [item for item in layout.items() if hasattr(item, "zoomToExtent")]
            if not map_items:
                issues.append(
                    PreflightIssue(
                        severity="BLOCK",
                        code="STRUCT-02",
                        title="Missing Map Viewport",
                        detail="The layout does not contain any map frame.",
                        remediation="Ensure the template contains at least one QgsLayoutItemMap with id 'main_map'.",
                    )
                )
                score -= 50
            else:
                issues.append(
                    PreflightIssue(
                        severity="PASS",
                        code="STRUCT-OK",
                        title="Map Frame Verified",
                        detail=f"Layout contains {len(map_items)} map frame(s).",
                        remediation="",
                    )
                )
        elif template_manifest:
            # Pre-generation wizard mode with verified template manifest
            req_roles = template_manifest.get("map_roles", [])
            issues.append(
                PreflightIssue(
                    severity="PASS",
                    code="STRUCT-OK",
                    title="Template Specification Verified",
                    detail=f"Template '{template_manifest.get('display_name', 'Selected Template')}' defines {len(req_roles)} map role(s).",
                    remediation="",
                )
            )
        else:
            issues.append(
                PreflightIssue(
                    severity="BLOCK",
                    code="STRUCT-01",
                    title="Layout Not Initialized",
                    detail="No valid print layout or template manifest was provided for evaluation.",
                    remediation="Select a valid template and initialize the layout.",
                )
            )
            return PreflightReport(passed=False, score=0, issues=issues)

        # 2. Data Presence & Required Roles Check
        if template_manifest:
            req_roles = [
                r.get("id")
                for r in template_manifest.get("map_roles", [])
                if r.get("required")
            ]
            for r_id in req_roles:
                layers = role_layers.get(r_id, [])
                if not layers:
                    # Check if project has any layers at all
                    issues.append(
                        PreflightIssue(
                            severity="BLOCK",
                            code="DATA-01",
                            title=f"Missing Layer for Required Role '{r_id}'",
                            detail=f"The role '{r_id}' is marked required but has no layers assigned.",
                            remediation="Select one or more active layers in Step 2 of the wizard.",
                        )
                    )
                    score -= 40
                else:
                    issues.append(
                        PreflightIssue(
                            severity="PASS",
                            code="DATA-OK",
                            title=f"Role '{r_id}' Bound",
                            detail=f"Assigned {len(layers)} layer(s) to '{r_id}'.",
                            remediation="",
                        )
                    )

        # 3. Spatial Extent Check
        for r_id, ext in role_extents.items():
            if ext is not None:
                if hasattr(ext, "isEmpty") and ext.isEmpty():
                    issues.append(
                        PreflightIssue(
                            severity="BLOCK",
                            code="EXT-01",
                            title=f"Invalid Extent for '{r_id}'",
                            detail="Bounding extent has zero or negative area.",
                            remediation="Ensure the target layer contains valid geometric features.",
                        )
                    )
                    score -= 30

        # 4. Cartographic Marginalia & Attribution Checks
        title = metadata.get("title", "").strip()
        if not title or title.lower() in ("untitled", "template title", "map title"):
            issues.append(
                PreflightIssue(
                    severity="WARNING",
                    code="ATTR-01",
                    title="Generic or Missing Title",
                    detail="The map title is empty or uses a generic placeholder.",
                    remediation="Enter a descriptive, communicative title identifying the subject and region.",
                )
            )
            score -= 10
        else:
            issues.append(
                PreflightIssue(
                    severity="PASS",
                    code="ATTR-TITLE-OK",
                    title="Title Configured",
                    detail=f"Title: '{title}'",
                    remediation="",
                )
            )

        source = metadata.get("source", "").strip()
        if not source:
            issues.append(
                PreflightIssue(
                    severity="WARNING",
                    code="ATTR-02",
                    title="Missing Data Source Attribution",
                    detail="No data source or scientific provenance is specified.",
                    remediation="Specify the data source and year of capture in Step 3.",
                )
            )
            score -= 15
        else:
            issues.append(
                PreflightIssue(
                    severity="PASS",
                    code="ATTR-SRC-OK",
                    title="Provenance Verified",
                    detail=f"Source: '{source}'",
                    remediation="",
                )
            )

        author = metadata.get("author", "").strip()
        if not author:
            issues.append(
                PreflightIssue(
                    severity="WARNING",
                    code="ATTR-03",
                    title="Missing Cartographer / Author",
                    detail="Author field is blank.",
                    remediation="Provide the cartographer or institutional author name.",
                )
            )
            score -= 5

        # 5. External Logo Verification
        if logo_path:
            if not os.path.isfile(logo_path):
                issues.append(
                    PreflightIssue(
                        severity="WARNING",
                        code="GRAPHIC-01",
                        title="Logo File Not Found",
                        detail=f"Specified logo path does not exist on disk: {logo_path}",
                        remediation="Select a valid image file (PNG, SVG, or JPG).",
                    )
                )
                score -= 10
            else:
                issues.append(
                    PreflightIssue(
                        severity="PASS",
                        code="GRAPHIC-OK",
                        title="Logo Asset Available",
                        detail="Institutional logo is accessible.",
                        remediation="",
                    )
                )

        # 6. Export Directory Check (if path supplied)
        if export_path:
            export_dir = os.path.dirname(os.path.abspath(export_path))
            if not os.path.isdir(export_dir):
                issues.append(
                    PreflightIssue(
                        severity="BLOCK",
                        code="EXP-01",
                        title="Target Directory Nonexistent",
                        detail=f"Output folder does not exist: {export_dir}",
                        remediation="Create the folder or select an existing folder.",
                    )
                )
                score -= 40
            elif not os.access(export_dir, os.W_OK):
                issues.append(
                    PreflightIssue(
                        severity="BLOCK",
                        code="EXP-02",
                        title="Target Directory Not Writable",
                        detail=f"Insufficient write permissions for: {export_dir}",
                        remediation="Choose a user-writable directory (e.g. Documents).",
                    )
                )
                score -= 40

        # Cap score between 0 and 100
        has_blocker = any(i.severity == "BLOCK" for i in issues)
        if has_blocker:
            score = min(score, 40)
        final_score = max(0, min(100, score))

        return PreflightReport(
            passed=not has_blocker,
            score=final_score,
            issues=issues,
        )
