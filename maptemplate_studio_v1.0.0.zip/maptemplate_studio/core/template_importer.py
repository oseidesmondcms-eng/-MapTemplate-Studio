"""
Template Importer and Sandboxing for MapTemplate Studio.
Validates, inspects, and registers user-supplied .qpt layout templates safely.
"""

import os
import shutil
import xml.etree.ElementTree as ET
from typing import Tuple, Optional, Dict, Any

from .settings_service import SettingsService
from .manifest_validator import ManifestValidator


MAX_TEMPLATE_BYTES = 20 * 1024 * 1024  # 20 Megabytes


class TemplateImporter:
    """Safely inspects and imports personal or third-party .qpt templates."""

    @classmethod
    def inspect_qpt(cls, file_path: str) -> Tuple[bool, Optional[Dict[str, Any]], Optional[str]]:
        """
        Inspects a .qpt file without executing or registering it.
        Returns (is_valid, metadata_summary, error_message).
        """
        if not os.path.isfile(file_path):
            return False, None, "File does not exist."

        # 1. Size check
        size = os.path.getsize(file_path)
        if size > MAX_TEMPLATE_BYTES:
            return False, None, f"File size ({round(size/(1024*1024), 1)} MB) exceeds 20 MB limit."

        # 2. XML Parsing & Security Check
        try:
            # Defend against XML vulnerabilities
            parser = ET.XMLParser()
            tree = ET.parse(file_path, parser=parser)
            root = tree.getroot()
        except Exception as e:
            return False, None, f"Malformed layout XML: {e}"

        # 3. Inspect items
        map_count = 0
        label_count = 0
        legend_count = 0
        scalebar_count = 0
        item_ids = []

        for item in root.findall(".//LayoutItem"):
            item_id = item.get("id", "")
            if item_id:
                item_ids.append(item_id)
            item_type = item.get("type", "")
            # QgsLayoutItemMap type code is 65639
            if item_type == "65639" or "map" in item_id.lower():
                map_count += 1
            elif item_type == "65641" or "label" in item_id.lower() or "title" in item_id.lower():
                label_count += 1
            elif item_type == "65642" or "legend" in item_id.lower():
                legend_count += 1
            elif item_type == "65646" or "scale" in item_id.lower():
                scalebar_count += 1

        summary = {
            "file_size_kb": round(size / 1024, 1),
            "map_count": map_count,
            "label_count": label_count,
            "legend_count": legend_count,
            "scalebar_count": scalebar_count,
            "item_ids": item_ids,
        }

        return True, summary, None

    @classmethod
    def import_template(
        cls,
        source_qpt_path: str,
        display_name: str,
        family: str = "general",
        archetype: str = "hero_map",
        page_size: str = "A4",
        orientation: str = "landscape",
        author: str = "",
        description: str = "",
        preview_image_path: Optional[str] = None,
    ) -> Tuple[bool, Optional[str], Optional[str]]:
        """
        Imports a validated .qpt file into the user's custom template directory.
        Returns (success: bool, template_id: Optional[str], error_message: Optional[str]).
        """
        valid, summary, err = cls.inspect_qpt(source_qpt_path)
        if not valid:
            return False, None, err

        settings = SettingsService()
        custom_root = settings.get_custom_templates_dir()

        # Generate unique ID e.g. USR-01, USR-02
        existing = [d for d in os.listdir(custom_root) if os.path.isdir(os.path.join(custom_root, d))]
        user_num = 1
        while f"USR-{user_num:02d}" in existing:
            user_num += 1
        template_id = f"USR-{user_num:02d}"

        target_dir = os.path.join(custom_root, template_id)
        os.makedirs(target_dir, exist_ok=True)

        target_qpt = os.path.join(target_dir, "layout.qpt")
        shutil.copy2(source_qpt_path, target_qpt)

        # Handle preview image
        preview_rel = "preview.png"
        target_preview = os.path.join(target_dir, preview_rel)
        if preview_image_path and os.path.isfile(preview_image_path):
            shutil.copy2(preview_image_path, target_preview)
        else:
            # Create a simple dummy preview if none provided
            with open(target_preview, "wb") as f:
                f.write(b"")

        # Build manifest
        manifest_data = {
            "schema_version": "1.0",
            "id": template_id,
            "display_name": display_name,
            "family": family,
            "archetype": archetype,
            "version": "1.0.0",
            "description": description or f"User imported template: {display_name}",
            "author": author or "User",
            "source": "imported",
            "license": "Custom / User-supplied",
            "qpt_path": "layout.qpt",
            "preview_path": preview_rel,
            "page": {
                "sizes": [page_size],
                "orientations": [orientation],
            },
            "map_roles": [
                {
                    "id": "main_map",
                    "required": True,
                    "fit": "canvas_extent",
                    "description": "Primary imported map viewport",
                }
            ],
            "fields": ["title", "subtitle", "source", "author", "date"],
            "style_tags": ["custom", "imported"],
            "export_presets": ["pdf_print_300", "png_digital_4k"],
            "assets": [],
            "compatibility": {
                "qgis_3_44": "compatible",
                "qgis_4_2": "compatible",
            },
        }

        import json
        manifest_path = os.path.join(target_dir, "manifest.json")
        with open(manifest_path, "w", encoding="utf-8") as f:
            json.dump(manifest_data, f, indent=2)

        return True, template_id, None
