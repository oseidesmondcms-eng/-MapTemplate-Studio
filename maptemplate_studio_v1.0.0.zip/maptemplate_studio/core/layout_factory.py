"""
Layout Factory for MapTemplate Studio.
Constructs, populates, and registers QGIS Print Layouts non-destructively.
"""

import os
from typing import Dict, Any, List, Optional, Tuple

try:
    from qgis.core import (
        QgsProject,
        QgsPrintLayout,
        QgsReadWriteContext,
        QgsMasterLayoutInterface,
    )
    from qgis.PyQt.QtXml import QDomDocument
    HAS_QGIS_CORE = True
except ImportError:
    HAS_QGIS_CORE = False

from .role_binder import RoleBinder


class LayoutFactory:
    """Instantiates QgsPrintLayouts from .qpt templates and commits them safely to QGIS projects."""

    @classmethod
    def get_unique_layout_name(cls, project: "QgsProject", base_name: str) -> str:
        """Ensures layout name does not collide with existing layouts in the project."""
        if not HAS_QGIS_CORE or not project:
            return base_name

        existing_names = set(
            l.name() for l in project.layoutManager().printLayouts()
        )
        if base_name not in existing_names:
            return base_name

        counter = 1
        while f"{base_name} ({counter})" in existing_names:
            counter += 1
        return f"{base_name} ({counter})"

    @classmethod
    def create_layout_from_template(
        cls,
        qpt_path: str,
        layout_name: str,
        role_layers: Optional[Dict[str, List[Any]]] = None,
        role_extents: Optional[Dict[str, Any]] = None,
        metadata: Optional[Dict[str, str]] = None,
        legend_config: Optional[Dict[str, Any]] = None,
        scalebar_config: Optional[Dict[str, Any]] = None,
        logo_path: Optional[str] = None,
        project: Optional["QgsProject"] = None,
    ) -> Tuple[Optional["QgsPrintLayout"], Optional[str]]:
        """
        Creates, binds, and adds a new QgsPrintLayout to the project.
        Returns (layout, error_message).
        """
        if not HAS_QGIS_CORE:
            return None, "QGIS core library not available."

        project = project or QgsProject.instance()
        if not project:
            return None, "No active QGIS project."

        if not os.path.isfile(qpt_path):
            return None, f"Template file does not exist: {qpt_path}"

        # 1. Read .qpt XML
        try:
            with open(qpt_path, "r", encoding="utf-8") as f:
                xml_content = f.read()
        except Exception as e:
            return None, f"Failed to read template file: {e}"

        doc = QDomDocument()
        if not doc.setContent(xml_content):
            return None, "Template XML is malformed."

        # 2. Instantiate new layout
        unique_name = cls.get_unique_layout_name(project, layout_name)
        layout = QgsPrintLayout(project)

        context = QgsReadWriteContext()
        loaded_items, ok = layout.loadFromTemplate(doc, context)
        if not ok and not loaded_items:
            return None, "Failed to instantiate layout items from template XML."

        # Ensure requested unique layout name is applied after template load
        layout.setName(unique_name)

        # 3. Bind Roles, Extents, and Metadata
        RoleBinder.bind_all(
            layout=layout,
            role_layers=role_layers or {},
            role_extents=role_extents or {},
            metadata=metadata or {},
            legend_config=legend_config,
            scalebar_config=scalebar_config,
            logo_path=logo_path,
        )

        # 4. Attach metadata as custom layout variables
        if metadata:
            for k, v in metadata.items():
                layout.setCustomProperty(f"maptemplate_{k}", str(v))

        # 5. Safely register in the project layout manager
        project.layoutManager().addLayout(layout)

        return layout, None
