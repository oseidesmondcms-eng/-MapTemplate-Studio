"""
Layout Exporter for MapTemplate Studio.
Handles multi-format production exports: PDF, Geospatial PDF, SVG, TIFF, and high-res PNG.
Provides memory estimation, progress feedback, and format-specific settings.
"""

import os
from typing import Tuple, Optional, Dict, Any

try:
    from qgis.core import (
        QgsLayoutExporter,
        QgsPrintLayout,
    )
    HAS_QGIS_CORE = True
except ImportError:
    HAS_QGIS_CORE = False


EXPORT_PRESETS = {
    "pdf_print_300": {
        "name": "Print Standard PDF (300 DPI)",
        "format": "pdf",
        "dpi": 300,
        "description": "Standard print quality PDF with vector line preservation.",
    },
    "pdf_print_600": {
        "name": "Print Detailed PDF (600 DPI)",
        "format": "pdf",
        "dpi": 600,
        "description": "Ultra-sharp print PDF for fine cartographic contours and surveying.",
    },
    "geospatial_pdf": {
        "name": "Geospatial PDF (300 DPI)",
        "format": "pdf",
        "dpi": 300,
        "geopdf": True,
        "description": "Geo-registered PDF allowing coordinate inspection in supported viewers.",
    },
    "png_preview": {
        "name": "Draft Preview (150 DPI)",
        "format": "png",
        "dpi": 150,
        "description": "Fast rendering for drafts and rapid proofing.",
    },
    "png_digital_4k": {
        "name": "Digital 4K PNG (3840 x 2160)",
        "format": "png",
        "dpi": 300,
        "description": "Ultra HD image optimized for widescreen digital presentations.",
    },
    "png_digital_1080p": {
        "name": "Full HD PNG (1920 x 1080)",
        "format": "png",
        "dpi": 150,
        "description": "Standard HD image for web and digital sharing.",
    },
    "svg_vector": {
        "name": "Scalable Vector Graphics (SVG)",
        "format": "svg",
        "dpi": 300,
        "description": "Vector output for editing in Inkscape or Adobe Illustrator.",
    },
    "tiff_hires": {
        "name": "High-Res TIFF (300 DPI)",
        "format": "tif",
        "dpi": 300,
        "description": "Uncompressed raster image for archive and graphic design workflows.",
    },
}


class LayoutExporter:
    """Orchestrates production-grade export of QgsPrintLayouts."""

    @classmethod
    def estimate_memory_mb(cls, page_width_mm: float, page_height_mm: float, dpi: int) -> float:
        """Estimates RAM required to rasterize a single page layout surface in Megabytes."""
        width_px = round((page_width_mm / 25.4) * dpi)
        height_px = round((page_height_mm / 25.4) * dpi)
        bytes_needed = width_px * height_px * 4  # 4 bytes per RGBA pixel
        return round(bytes_needed / (1024 * 1024), 2)

    @classmethod
    def export(
        cls,
        layout: "QgsPrintLayout",
        output_path: str,
        preset_id: str = "pdf_print_300",
    ) -> Tuple[bool, Optional[str]]:
        """
        Exports the layout according to the chosen preset.
        Returns (success: bool, error_message: Optional[str]).
        """
        if not HAS_QGIS_CORE or not layout:
            return False, "QGIS layout engine is not available."

        out_dir = os.path.dirname(os.path.abspath(output_path))
        if not os.path.isdir(out_dir):
            try:
                os.makedirs(out_dir, exist_ok=True)
            except Exception as e:
                return False, f"Failed to create output directory: {e}"

        preset = EXPORT_PRESETS.get(preset_id, EXPORT_PRESETS["pdf_print_300"])
        fmt = preset["format"]
        dpi = preset.get("dpi", 300)

        exporter = QgsLayoutExporter(layout)

        try:
            if fmt == "pdf":
                pdf_settings = QgsLayoutExporter.PdfExportSettings()
                pdf_settings.dpi = dpi
                if preset.get("geopdf") and hasattr(pdf_settings, "writeGeoPdf"):
                    pdf_settings.writeGeoPdf = True

                result = exporter.exportToPdf(output_path, pdf_settings)
                if result == QgsLayoutExporter.Success:
                    return True, None
                return False, f"PDF export failed with error code: {result}"

            elif fmt in ("png", "tif", "jpg"):
                img_settings = QgsLayoutExporter.ImageExportSettings()
                img_settings.dpi = dpi
                result = exporter.exportToImage(output_path, img_settings)
                if result == QgsLayoutExporter.Success:
                    return True, None
                return False, f"Image export failed with error code: {result}"

            elif fmt == "svg":
                svg_settings = QgsLayoutExporter.SvgExportSettings()
                svg_settings.dpi = dpi
                result = exporter.exportToSvg(output_path, svg_settings)
                if result == QgsLayoutExporter.Success:
                    return True, None
                return False, f"SVG export failed with error code: {result}"

            else:
                return False, f"Unsupported export format '{fmt}'"

        except Exception as e:
            return False, f"Export exception: {str(e)}"
