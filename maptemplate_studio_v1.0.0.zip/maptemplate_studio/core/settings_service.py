"""
Settings service for MapTemplate Studio.
Handles user preferences, favorites, recently used templates, and defaults.
Uses QgsSettings when available, with a graceful local JSON fallback for standalone testing.
"""

import os
import json
from pathlib import Path

try:
    from qgis.core import QgsSettings
    HAS_QGIS_SETTINGS = True
except ImportError:
    HAS_QGIS_SETTINGS = False


class SettingsService:
    """Manages persistent plugin settings and user preferences."""

    PREFIX = "MapTemplateStudio/"

    def __init__(self, fallback_dir=None):
        self._fallback_dir = fallback_dir or os.path.join(
            Path.home(), ".maptemplate_studio"
        )
        self._fallback_file = os.path.join(self._fallback_dir, "settings.json")
        self._in_memory_cache = {}
        self._load_fallback()

    def _load_fallback(self):
        if not HAS_QGIS_SETTINGS and os.path.exists(self._fallback_file):
            try:
                with open(self._fallback_file, "r", encoding="utf-8") as f:
                    self._in_memory_cache = json.load(f)
            except Exception:
                self._in_memory_cache = {}

    def _save_fallback(self):
        if not HAS_QGIS_SETTINGS:
            try:
                os.makedirs(self._fallback_dir, exist_ok=True)
                with open(self._fallback_file, "w", encoding="utf-8") as f:
                    json.dump(self._in_memory_cache, f, indent=2)
            except Exception:
                pass

    def get_value(self, key, default=None):
        """Retrieve a stored setting."""
        val = None
        if HAS_QGIS_SETTINGS:
            try:
                settings = QgsSettings()
                val = settings.value(f"{self.PREFIX}{key}")
            except Exception:
                val = None
        if val is None or val == "":
            return self._in_memory_cache.get(key, default)
        return val

    def set_value(self, key, value):
        """Store a setting."""
        self._in_memory_cache[key] = value
        self._save_fallback()
        if HAS_QGIS_SETTINGS:
            try:
                settings = QgsSettings()
                settings.setValue(f"{self.PREFIX}{key}", value)
            except Exception:
                pass

    # --- Favorites Management ---
    def get_favorites(self) -> list:
        """Returns list of favorite template IDs."""
        val = self.get_value("favorites", [])
        if isinstance(val, str):
            try:
                return json.loads(val)
            except Exception:
                return []
        return list(val) if isinstance(val, (list, tuple)) else []

    def is_favorite(self, template_id: str) -> bool:
        return template_id in self.get_favorites()

    def toggle_favorite(self, template_id: str) -> bool:
        """Toggles a template in favorites. Returns True if now favorite, False otherwise."""
        favs = self.get_favorites()
        if template_id in favs:
            favs.remove(template_id)
            is_fav = False
        else:
            favs.append(template_id)
            is_fav = True
        self.set_value("favorites", json.dumps(favs) if HAS_QGIS_SETTINGS else favs)
        return is_fav

    # --- Recently Used Management ---
    def get_recently_used(self) -> list:
        """Returns list of recently used template IDs."""
        val = self.get_value("recently_used", [])
        if isinstance(val, str):
            try:
                return json.loads(val)
            except Exception:
                return []
        return list(val) if isinstance(val, (list, tuple)) else []

    def record_used_template(self, template_id: str, max_items: int = 10):
        """Records a template as recently used (most recent first)."""
        recent = self.get_recently_used()
        if template_id in recent:
            recent.remove(template_id)
        recent.insert(0, template_id)
        recent = recent[:max_items]
        self.set_value("recently_used", json.dumps(recent) if HAS_QGIS_SETTINGS else recent)

    # --- Defaults & Custom Directory ---
    def get_default_author(self) -> str:
        return self.get_value("default_author", "")

    def set_default_author(self, author: str):
        self.set_value("default_author", author)

    def get_default_organization(self) -> str:
        return self.get_value("default_organization", "")

    def set_default_organization(self, org: str):
        self.set_value("default_organization", org)

    def get_last_export_dir(self) -> str:
        return self.get_value("last_export_dir", str(Path.home()))

    def set_last_export_dir(self, directory: str):
        self.set_value("last_export_dir", directory)

    def get_custom_templates_dir(self) -> str:
        """Returns the user custom template directory (writable)."""
        default_dir = os.path.join(Path.home(), ".maptemplate_studio", "custom_templates")
        custom_dir = self.get_value("custom_templates_dir", default_dir)
        try:
            os.makedirs(custom_dir, exist_ok=True)
        except Exception:
            pass
        return custom_dir

    def set_custom_templates_dir(self, path: str):
        self.set_value("custom_templates_dir", path)
