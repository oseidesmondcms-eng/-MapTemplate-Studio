"""
Export Dialog for MapTemplate Studio.
Configures and executes production exports: PDF, Geospatial PDF, SVG, TIFF, and high-res PNG.
"""

import os
from typing import Optional

try:
    from qgis.PyQt import QtCore, QtGui, QtWidgets
    from qgis.PyQt.QtCore import Qt
    from qgis.PyQt.QtWidgets import (
        QDialog,
        QVBoxLayout,
        QFormLayout,
        QHBoxLayout,
        QLabel,
        QComboBox,
        QLineEdit,
        QPushButton,
        QFileDialog,
        QMessageBox,
        QDialogButtonBox,
    )
    from qgis.core import QgsPrintLayout
    HAS_QT = True
except ImportError:
    HAS_QT = False

try:
    from ..core.exporter import LayoutExporter, EXPORT_PRESETS
    from ..core.settings_service import SettingsService
    from .theme import QGISTheme
except (ImportError, ValueError):
    from core.exporter import LayoutExporter, EXPORT_PRESETS
    from core.settings_service import SettingsService
    from ui.theme import QGISTheme


class ExportDialog(QDialog):
    """Production export configuration dialog."""

    def __init__(self, layout: "QgsPrintLayout", parent=None):
        super().__init__(parent)
        self.layout = layout
        self.settings = SettingsService()
        self.setWindowTitle("Export Map Layout — MapTemplate Studio")
        self.setMinimumWidth(520)
        self._init_ui()

    def _init_ui(self):
        main_layout = QVBoxLayout(self)
        main_layout.setSpacing(12)
        main_layout.setContentsMargins(14, 14, 14, 14)

        form = QFormLayout()
        form.setSpacing(10)

        # 1. Preset Selector
        self.preset_combo = QComboBox(self)
        for p_id, p_info in EXPORT_PRESETS.items():
            self.preset_combo.addItem(p_info["name"], p_id)
        self.preset_combo.currentIndexChanged.connect(self._on_preset_changed)
        form.addRow("Export Preset:", self.preset_combo)

        # Preset description label
        self.preset_desc = QLabel(self)
        self.preset_desc.setStyleSheet("color: palette(mid); font-size: 8.5pt;")
        self.preset_desc.setWordWrap(True)
        form.addRow("", self.preset_desc)

        # 2. Output File Path
        path_row = QHBoxLayout()
        self.path_edit = QLineEdit(self)
        self.path_edit.setPlaceholderText("Select destination path...")
        path_row.addWidget(self.path_edit)

        self.browse_btn = QPushButton("Browse...", self)
        self.browse_btn.clicked.connect(self._browse_output)
        path_row.addWidget(self.browse_btn)
        form.addRow("Destination:", path_row)

        # 3. Memory Estimate Info
        self.mem_lbl = QLabel(self)
        self.mem_lbl.setStyleSheet("color: palette(mid); font-size: 8.5pt;")
        form.addRow("Memory Footprint:", self.mem_lbl)

        main_layout.addLayout(form)
        main_layout.addStretch()

        # Action Buttons
        self.btn_box = QDialogButtonBox(
            QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel,
            self,
        )
        self.export_btn = self.btn_box.button(QDialogButtonBox.StandardButton.Ok)
        self.export_btn.setText("Export Now")
        self.export_btn.setObjectName("PrimaryButton")

        self.btn_box.accepted.connect(self._do_export)
        self.btn_box.rejected.connect(self.reject)
        main_layout.addWidget(self.btn_box)

        # Initialize preset display
        self._on_preset_changed()

    def _on_preset_changed(self):
        p_id = self.preset_combo.currentData()
        preset = EXPORT_PRESETS.get(p_id, {})
        self.preset_desc.setText(preset.get("description", ""))

        # Update default filename with proper extension
        ext = preset.get("format", "pdf")
        default_dir = self.settings.get_last_export_dir()
        base_name = self.layout.name() if self.layout else "map_export"
        clean_name = "".join(c for c in base_name if c.isalnum() or c in ("-", "_", " ")).strip()
        default_path = os.path.join(default_dir, f"{clean_name}.{ext}")
        self.path_edit.setText(default_path)

        # Update memory estimate
        if self.layout:
            page = self.layout.pageCollection().page(0)
            page_w = page.pageSize().width()
            page_h = page.pageSize().height()
            dpi = preset.get("dpi", 300)
            mem_mb = LayoutExporter.estimate_memory_mb(page_w, page_h, dpi)
            self.mem_lbl.setText(f"Estimated surface rasterization: ~{mem_mb} MB RAM")

    def _browse_output(self):
        p_id = self.preset_combo.currentData()
        preset = EXPORT_PRESETS.get(p_id, {})
        fmt = preset.get("format", "pdf")

        filters = {
            "pdf": "PDF Files (*.pdf)",
            "png": "PNG Images (*.png)",
            "svg": "Scalable Vector Graphics (*.svg)",
            "tif": "TIFF Images (*.tif *.tiff)",
        }
        filter_str = filters.get(fmt, "All Files (*.*)")

        path, _ = QFileDialog.getSaveFileName(
            self,
            "Select Output Destination",
            self.path_edit.text(),
            filter_str,
        )
        if path:
            self.path_edit.setText(path)
            self.settings.set_last_export_dir(os.path.dirname(path))

    def _do_export(self):
        out_path = self.path_edit.text().strip()
        if not out_path:
            QMessageBox.warning(self, "Invalid Path", "Please specify an output file destination.")
            return

        p_id = self.preset_combo.currentData()
        self.export_btn.setEnabled(False)
        self.export_btn.setText("Exporting...")
        QtWidgets.QApplication.processEvents()

        success, err = LayoutExporter.export(self.layout, out_path, preset_id=p_id)
        self.export_btn.setEnabled(True)
        self.export_btn.setText("Export Now")

        if success:
            QMessageBox.information(
                self,
                "Export Complete",
                f"Layout exported successfully to:\n{out_path}",
            )
            self.accept()
        else:
            QMessageBox.critical(
                self,
                "Export Failed",
                f"Failed to export layout:\n{err}",
            )
