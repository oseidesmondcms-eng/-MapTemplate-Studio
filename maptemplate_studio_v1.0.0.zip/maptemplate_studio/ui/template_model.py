"""
Template Card Widget and Display Model for MapTemplate Studio.
Renders responsive preview cards with thumbnails, archetype pills, and favorite toggles.
"""

from typing import Dict, Any, Optional

try:
    from qgis.PyQt import QtCore, QtGui, QtWidgets
    from qgis.PyQt.QtCore import Qt, pyqtSignal
    from qgis.PyQt.QtGui import QPixmap, QIcon, QPainter, QColor
    from qgis.PyQt.QtWidgets import (
        QWidget,
        QFrame,
        QVBoxLayout,
        QHBoxLayout,
        QLabel,
        QToolButton,
        QSizePolicy,
    )
    HAS_QT = True
except ImportError:
    HAS_QT = False

from .theme import QGISTheme


class TemplateCardWidget(QFrame):
    """Interactive visual card representing a single map layout template in the gallery."""

    clicked = pyqtSignal(str)          # Emits template_id
    doubleClicked = pyqtSignal(str)    # Emits template_id
    favoriteToggled = pyqtSignal(str)  # Emits template_id

    def __init__(self, template_data: Dict[str, Any], parent=None):
        super().__init__(parent)
        self.template_data = template_data
        self.template_id = template_data["id"]
        self._is_selected = False
        self._init_ui()

    def _init_ui(self):
        self.setObjectName("TemplateCard")
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
        self.setFixedHeight(230)
        self.setMinimumWidth(210)

        main_layout = QVBoxLayout(self)
        main_layout.setContentsMargins(8, 8, 8, 8)
        main_layout.setSpacing(6)

        # 1. Thumbnail Container
        self.thumb_label = QLabel(self)
        self.thumb_label.setFixedHeight(130)
        self.thumb_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.thumb_label.setStyleSheet("background-color: palette(base); border-radius: 4px;")

        preview_path = self.template_data.get("preview_abs_path")
        if preview_path:
            pix = QPixmap(preview_path)
            if not pix.isNull():
                scaled = pix.scaled(
                    230,
                    130,
                    Qt.AspectRatioMode.KeepAspectRatio,
                    Qt.TransformationMode.SmoothTransformation,
                )
                self.thumb_label.setPixmap(scaled)
            else:
                self.thumb_label.setText("No Preview")
        else:
            self.thumb_label.setText("No Preview")

        main_layout.addWidget(self.thumb_label)

        # 2. Title & Favorite Star Row
        title_row = QHBoxLayout()
        title_row.setContentsMargins(0, 0, 0, 0)
        title_row.setSpacing(4)

        self.title_label = QLabel(self.template_data.get("display_name", self.template_id), self)
        self.title_label.setObjectName("CardTitle")
        self.title_label.setToolTip(self.template_data.get("description", ""))
        self.title_label.setWordWrap(False)
        self.title_label.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Preferred)
        title_row.addWidget(self.title_label)

        # Favorite button
        self.fav_btn = QToolButton(self)
        self.fav_btn.setCheckable(True)
        self.fav_btn.setChecked(self.template_data.get("is_favorite", False))
        self._update_star_icon()
        self.fav_btn.clicked.connect(self._on_fav_clicked)
        title_row.addWidget(self.fav_btn)

        main_layout.addLayout(title_row)

        # 3. Badges Row (Archetype, Family, Page Size)
        badge_row = QHBoxLayout()
        badge_row.setContentsMargins(0, 0, 0, 0)
        badge_row.setSpacing(4)

        # ID pill
        id_pill = QLabel(self.template_id, self)
        id_pill.setObjectName("BadgePill")
        badge_row.addWidget(id_pill)

        # Archetype pill
        archetype_name = self.template_data.get("archetype", "").replace("_", " ").title()
        arch_pill = QLabel(archetype_name, self)
        arch_pill.setObjectName("BadgePill")
        badge_row.addWidget(arch_pill)

        # Page Size pill
        page_sizes = self.template_data.get("page", {}).get("sizes", ["A4"])
        size_pill = QLabel(page_sizes[0], self)
        size_pill.setObjectName("BadgePill")
        badge_row.addWidget(size_pill)

        badge_row.addStretch()
        main_layout.addLayout(badge_row)

    def _update_star_icon(self):
        if self.fav_btn.isChecked():
            self.fav_btn.setText("★")
            self.fav_btn.setStyleSheet("color: #eab308; font-size: 13pt; border: none; background: transparent;")
        else:
            self.fav_btn.setText("☆")
            self.fav_btn.setStyleSheet("color: #94a3b8; font-size: 13pt; border: none; background: transparent;")

    def _on_fav_clicked(self):
        self._update_star_icon()
        self.favoriteToggled.emit(self.template_id)

    def set_selected(self, selected: bool):
        self._is_selected = selected
        self.setProperty("selected", "true" if selected else "false")
        self.style().unpolish(self)
        self.style().polish(self)
        self.update()

    def mousePressEvent(self, event):
        if event.button() == Qt.MouseButton.LeftButton:
            self.clicked.emit(self.template_id)
        super().mousePressEvent(event)

    def mouseDoubleClickEvent(self, event):
        if event.button() == Qt.MouseButton.LeftButton:
            self.doubleClicked.emit(self.template_id)
        super().mouseDoubleClickEvent(event)
