"""
Four-Stage Guided Layout Creation Wizard for MapTemplate Studio.
Guides users through template options, layer binding, cartographic metadata,
preflight validation, and layout generation.
"""

import os
from datetime import datetime
from typing import Dict, Any, Optional, List

try:
    from qgis.PyQt import QtCore, QtGui, QtWidgets
    from qgis.PyQt.QtCore import Qt, pyqtSignal
    from qgis.PyQt.QtWidgets import (
        QDialog,
        QVBoxLayout,
        QHBoxLayout,
        QFormLayout,
        QTabWidget,
        QWidget,
        QLabel,
        QLineEdit,
        QComboBox,
        QSpinBox,
        QCheckBox,
        QPushButton,
        QMessageBox,
        QScrollArea,
        QFrame,
        QFileDialog,
    )
    from qgis.core import (
        QgsProject,
        QgsMapLayer,
        QgsMapLayerProxyModel,
    )
    from qgis.gui import (
        QgsMapLayerComboBox,
        QgsCollapsibleGroupBox,
        QgsFileWidget,
    )
    HAS_QGIS_GUI = True
except ImportError:
    HAS_QGIS_GUI = False

try:
    from ..core.layout_factory import LayoutFactory
    from ..core.preflight import PreflightChecker, PreflightReport
    from ..core.settings_service import SettingsService
    from ..core.extent_scale import ExtentScaleResolver
    from .theme import QGISTheme
    from .preflight_dialog import PreflightDialog
except (ImportError, ValueError):
    from core.layout_factory import LayoutFactory
    from core.preflight import PreflightChecker, PreflightReport
    from core.settings_service import SettingsService
    from core.extent_scale import ExtentScaleResolver
    from ui.theme import QGISTheme
    from ui.preflight_dialog import PreflightDialog


class WizardDialog(QDialog):
    """Four-step guided layout wizard dialog."""

    layoutCreated = pyqtSignal(object)  # Emits generated QgsPrintLayout

    def __init__(self, template_data: Dict[str, Any], iface=None, parent=None):
        super().__init__(parent)
        self.template_data = template_data
        self.iface = iface
        self.settings = SettingsService()
        self.setWindowTitle(f"Create Map Layout — {self.template_data.get('display_name')}")
        self.resize(720, 560)
        self.setObjectName("WizardDialog")
        self.setStyleSheet(QGISTheme.get_wizard_stylesheet())
        self._init_ui()

    def _init_ui(self):
        main_layout = QVBoxLayout(self)
        main_layout.setContentsMargins(12, 12, 12, 12)
        main_layout.setSpacing(10)

        # Tab Widget (4 Steps)
        self.tabs = QTabWidget(self)
        self.step1_widget = self._create_step1_tab()
        self.step2_widget = self._create_step2_tab()
        self.step3_widget = self._create_step3_tab()
        self.step4_widget = self._create_step4_tab()

        self.tabs.addTab(self.step1_widget, "1. Template & Format")
        self.tabs.addTab(self.step2_widget, "2. Map Content")
        self.tabs.addTab(self.step3_widget, "3. Cartography & Marginalia")
        self.tabs.addTab(self.step4_widget, "4. Review & Generate")
        main_layout.addWidget(self.tabs)

        # Wizard Navigation Buttons
        nav_row = QHBoxLayout()
        self.back_btn = QPushButton("◀ Back", self)
        self.back_btn.clicked.connect(self._prev_step)
        nav_row.addWidget(self.back_btn)

        nav_row.addStretch()

        self.next_btn = QPushButton("Next ▶", self)
        self.next_btn.clicked.connect(self._next_step)
        nav_row.addWidget(self.next_btn)

        self.generate_btn = QPushButton("✓ Generate Layout", self)
        self.generate_btn.setObjectName("PrimaryButton")
        self.generate_btn.clicked.connect(self._generate_layout)
        nav_row.addWidget(self.generate_btn)

        self.cancel_btn = QPushButton("Cancel", self)
        self.cancel_btn.clicked.connect(self.reject)
        nav_row.addWidget(self.cancel_btn)

        main_layout.addLayout(nav_row)

        self.tabs.currentChanged.connect(self._on_tab_changed)
        self._update_nav_state()

    # -------------------------------------------------------------
    # Step 1: Template & Format Specs
    # -------------------------------------------------------------
    def _create_step1_tab(self) -> QWidget:
        widget = QWidget(self)
        layout = QVBoxLayout(widget)

        # Overview banner
        banner = QFrame(widget)
        banner.setFrameShape(QFrame.Shape.StyledPanel)
        b_layout = QHBoxLayout(banner)

        # Thumbnail preview
        thumb = QLabel(banner)
        thumb.setFixedSize(140, 95)
        thumb.setAlignment(Qt.AlignmentFlag.AlignCenter)
        preview_path = self.template_data.get("preview_abs_path")
        if preview_path and os.path.isfile(preview_path):
            pix = QtGui.QPixmap(preview_path).scaled(140, 95, Qt.AspectRatioMode.KeepAspectRatio)
            thumb.setPixmap(pix)
        else:
            thumb.setText("No Preview")
        b_layout.addWidget(thumb)

        # Metadata text
        v_meta = QVBoxLayout()
        name_lbl = QLabel(f"<b>{self.template_data.get('display_name')}</b> ({self.template_data.get('id')})", banner)
        v_meta.addWidget(name_lbl)
        desc_lbl = QLabel(self.template_data.get("description", ""), banner)
        desc_lbl.setWordWrap(True)
        v_meta.addWidget(desc_lbl)
        b_layout.addLayout(v_meta)
        layout.addWidget(banner)

        # Configuration Form
        form = QFormLayout()
        form.setSpacing(10)

        # Page Size
        self.size_combo = QComboBox(widget)
        supported_sizes = self.template_data.get("page", {}).get("sizes", ["A4"])
        for sz in supported_sizes:
            self.size_combo.addItem(sz, sz)
        form.addRow("Paper / Canvas Size:", self.size_combo)

        # Orientation
        self.ori_combo = QComboBox(widget)
        supported_oris = self.template_data.get("page", {}).get("orientations", ["landscape"])
        for ori in supported_oris:
            self.ori_combo.addItem(ori.title(), ori)
        form.addRow("Orientation:", self.ori_combo)

        # Style System
        self.style_combo = QComboBox(widget)
        styles = [
            ("Corporate Branded (Modern Clean)", "corporate_branded"),
            ("Minimal Academic (Publication Grade)", "minimal_academic"),
            ("Classic Survey (Formal Cadastral)", "classic_survey"),
            ("Modern Editorial (Magazine / Web)", "modern_editorial"),
            ("Humanitarian Neutral (Standard Carto)", "humanitarian_neutral"),
            ("Government Formal (Official Planning)", "government_formal"),
            ("Topographic Heritage (Earth Tones)", "topographic_heritage"),
            ("Dark Digital (Screen / Projection)", "dark_digital"),
        ]
        for name, val in styles:
            self.style_combo.addItem(name, val)
        form.addRow("Visual Style System:", self.style_combo)

        layout.addLayout(form)
        layout.addStretch()
        return widget

    # -------------------------------------------------------------
    # Step 2: Map Content & Layer Binding
    # -------------------------------------------------------------
    def _create_step2_tab(self) -> QWidget:
        widget = QWidget(self)
        layout = QVBoxLayout(widget)

        scroll = QScrollArea(widget)
        scroll.setWidgetResizable(True)
        scroll_content = QWidget()
        scroll_layout = QVBoxLayout(scroll_content)

        self.role_combos = {}
        self.role_extent_modes = {}
        self.padding_spins = {}

        roles = self.template_data.get("map_roles", [{"id": "main_map", "required": True}])

        for role in roles:
            r_id = role.get("id", "main_map")
            r_desc = role.get("description", r_id)
            is_req = role.get("required", False)

            group_title = f"Map Viewport: {r_id} {'(Required)' if is_req else '(Optional)'}"
            group = QgsCollapsibleGroupBox(group_title, scroll_content) if HAS_QGIS_GUI else QtWidgets.QGroupBox(group_title, scroll_content)
            g_layout = QFormLayout(group)

            # Layer combo
            layer_combo = QgsMapLayerComboBox(group) if HAS_QGIS_GUI else QComboBox(group)
            if not HAS_QGIS_GUI:
                layer_combo.addItem("Current Active Layer", None)
            else:
                # Add "All Visible Project Layers" option
                layer_combo.setFilters(QgsMapLayerProxyModel.Filter.All)
            g_layout.addRow("Assigned Source Layer:", layer_combo)
            self.role_combos[r_id] = layer_combo

            # Extent mode
            mode_combo = QComboBox(group)
            mode_combo.addItem("Current Map Canvas Extent", "canvas")
            mode_combo.addItem("Assigned Layer Extent", "layer")
            mode_combo.addItem("Fixed Scale (Maintain Aspect)", "fixed")
            g_layout.addRow("Extent Fitting Mode:", mode_combo)
            self.role_extent_modes[r_id] = mode_combo

            # Margin Padding
            pad_spin = QSpinBox(group)
            pad_spin.setRange(0, 50)
            pad_spin.setValue(5)
            pad_spin.setSuffix("%")
            g_layout.addRow("Margin Padding:", pad_spin)
            self.padding_spins[r_id] = pad_spin

            scroll_layout.addWidget(group)

        scroll_layout.addStretch()
        scroll.setWidget(scroll_content)
        layout.addWidget(scroll)
        return widget

    # -------------------------------------------------------------
    # Step 3: Cartography & Marginalia
    # -------------------------------------------------------------
    def _create_step3_tab(self) -> QWidget:
        widget = QWidget(self)
        layout = QVBoxLayout(widget)

        scroll = QScrollArea(widget)
        scroll.setWidgetResizable(True)
        scroll_content = QWidget()
        form = QFormLayout(scroll_content)
        form.setSpacing(8)

        # Title & Subtitle
        self.title_edit = QLineEdit(scroll_content)
        self.title_edit.setText(self.template_data.get("display_name", "Untitled Map"))
        form.addRow("Map Title:", self.title_edit)

        self.subtitle_edit = QLineEdit(scroll_content)
        self.subtitle_edit.setPlaceholderText("e.g. Study Area Overview & Classification")
        form.addRow("Subtitle / Scope:", self.subtitle_edit)

        # Provenance
        self.source_edit = QLineEdit(scroll_content)
        self.source_edit.setText("OpenStreetMap contributors, Earth Observation Data")
        form.addRow("Data Source(s):", self.source_edit)

        # Author & Organization
        self.author_edit = QLineEdit(scroll_content)
        self.author_edit.setText(self.settings.get_default_author() or "Cartography Unit")
        form.addRow("Author / Cartographer:", self.author_edit)

        self.org_edit = QLineEdit(scroll_content)
        self.org_edit.setText(self.settings.get_default_organization() or "GIS Division")
        form.addRow("Organization / Client:", self.org_edit)

        # Date & CRS
        self.date_edit = QLineEdit(scroll_content)
        self.date_edit.setText(datetime.now().strftime("%B %Y"))
        form.addRow("Publication Date:", self.date_edit)

        # Auto-detect CRS from project
        proj_crs = QgsProject.instance().crs().description() if HAS_QGIS_GUI else "WGS 84 / UTM"
        self.crs_edit = QLineEdit(scroll_content)
        self.crs_edit.setText(proj_crs)
        form.addRow("Coordinate System:", self.crs_edit)

        # Legend Options Box
        leg_box = QgsCollapsibleGroupBox("Legend Configuration", scroll_content) if HAS_QGIS_GUI else QtWidgets.QGroupBox("Legend Configuration", scroll_content)
        l_form = QFormLayout(leg_box)
        self.leg_check = QCheckBox("Include Map Legend", leg_box)
        self.leg_check.setChecked(True)
        l_form.addRow(self.leg_check)

        self.leg_filter_check = QCheckBox("Filter Legend to Visible Map Extent", leg_box)
        self.leg_filter_check.setChecked(False)
        l_form.addRow(self.leg_filter_check)

        self.leg_cols = QSpinBox(leg_box)
        self.leg_cols.setRange(1, 4)
        self.leg_cols.setValue(1)
        l_form.addRow("Columns:", self.leg_cols)
        form.addRow(leg_box)

        # Scale Bar Box
        sb_box = QgsCollapsibleGroupBox("Scale Bar & North Arrow", scroll_content) if HAS_QGIS_GUI else QtWidgets.QGroupBox("Scale Bar & North Arrow", scroll_content)
        s_form = QFormLayout(sb_box)
        self.sb_check = QCheckBox("Include Scale Bar", sb_box)
        self.sb_check.setChecked(True)
        s_form.addRow(self.sb_check)

        self.sb_units = QComboBox(sb_box)
        self.sb_units.addItem("Kilometers (km)", "km")
        self.sb_units.addItem("Meters (m)", "m")
        self.sb_units.addItem("Miles (mi)", "mi")
        s_form.addRow("Scale Units:", self.sb_units)

        self.na_check = QCheckBox("Include North Arrow", sb_box)
        self.na_check.setChecked(True)
        s_form.addRow(self.na_check)
        form.addRow(sb_box)

        # Logo Picker Row
        logo_row = QHBoxLayout()
        self.logo_edit = QLineEdit(scroll_content)
        self.logo_edit.setPlaceholderText("Select institutional logo (optional)...")
        logo_row.addWidget(self.logo_edit)

        self.logo_browse = QPushButton("Browse...", scroll_content)
        self.logo_browse.clicked.connect(self._browse_logo)
        logo_row.addWidget(self.logo_browse)
        form.addRow("Organization Logo:", logo_row)

        scroll.setWidget(scroll_content)
        layout.addWidget(scroll)
        return widget

    def _browse_logo(self):
        path, _ = QFileDialog.getOpenFileName(
            self,
            "Select Organization Logo",
            "",
            "Images (*.png *.svg *.jpg *.jpeg);;All Files (*.*)",
        )
        if path:
            self.logo_edit.setText(path)

    # -------------------------------------------------------------
    # Step 4: Review & Generate
    # -------------------------------------------------------------
    def _create_step4_tab(self) -> QWidget:
        widget = QWidget(self)
        layout = QVBoxLayout(widget)

        # Preflight Summary Header
        self.preflight_box = QFrame(widget)
        self.preflight_box.setFrameShape(QFrame.Shape.StyledPanel)
        pf_layout = QHBoxLayout(self.preflight_box)

        self.pf_status_lbl = QLabel(self.preflight_box)
        self.pf_status_lbl.setStyleSheet("font-size: 11pt; font-weight: bold;")
        pf_layout.addWidget(self.pf_status_lbl)

        pf_layout.addStretch()

        self.details_btn = QPushButton("View Preflight Report...", self.preflight_box)
        self.details_btn.clicked.connect(self._show_preflight_details)
        pf_layout.addWidget(self.details_btn)
        layout.addWidget(self.preflight_box)

        # Generation Options Form
        form = QFormLayout()
        form.setSpacing(10)

        # Unique layout name
        self.layout_name_edit = QLineEdit(widget)
        suggested_name = f"{self.template_data.get('display_name')}"
        if HAS_QGIS_GUI:
            suggested_name = LayoutFactory.get_unique_layout_name(
                QgsProject.instance(), suggested_name
            )
        self.layout_name_edit.setText(suggested_name)
        form.addRow("Layout Name in Project:", self.layout_name_edit)

        # Open in Designer Toggle
        self.open_designer_check = QCheckBox("Open immediately in QGIS Layout Designer", widget)
        self.open_designer_check.setChecked(True)
        form.addRow(self.open_designer_check)

        layout.addLayout(form)
        layout.addStretch()
        return widget

    def _update_nav_state(self):
        curr = self.tabs.currentIndex()
        self.back_btn.setEnabled(curr > 0)
        self.next_btn.setVisible(curr < 3)
        self.generate_btn.setVisible(curr == 3)

    def _on_tab_changed(self, idx):
        self._update_nav_state()
        if idx == 3:
            self._run_live_preflight()

    def _prev_step(self):
        idx = self.tabs.currentIndex()
        if idx > 0:
            self.tabs.setCurrentIndex(idx - 1)

    def _next_step(self):
        idx = self.tabs.currentIndex()
        if idx < 3:
            self.tabs.setCurrentIndex(idx + 1)

    def _collect_role_layers_and_extents(self):
        role_layers = {}
        role_extents = {}

        for r_id, combo in self.role_combos.items():
            layer = None
            if HAS_QGIS_GUI and hasattr(combo, "currentLayer"):
                layer = combo.currentLayer()

            if layer:
                role_layers[r_id] = [layer]
                mode = self.role_extent_modes[r_id].currentData()
                if mode == "layer":
                    role_extents[r_id] = layer.extent()
                elif mode == "canvas" and self.iface:
                    role_extents[r_id] = self.iface.mapCanvas().extent()
                else:
                    role_extents[r_id] = layer.extent()
            else:
                # Fallback to canvas extent
                if self.iface:
                    role_extents[r_id] = self.iface.mapCanvas().extent()
                    canvas_layers = self.iface.mapCanvas().layers()
                    if canvas_layers:
                        role_layers[r_id] = canvas_layers

        return role_layers, role_extents

    def _run_live_preflight(self):
        role_layers, role_extents = self._collect_role_layers_and_extents()
        metadata = {
            "title": self.title_edit.text().strip(),
            "subtitle": self.subtitle_edit.text().strip(),
            "source": self.source_edit.text().strip(),
            "author": self.author_edit.text().strip(),
            "organization": self.org_edit.text().strip(),
            "date": self.date_edit.text().strip(),
            "crs": self.crs_edit.text().strip(),
        }

        # Run preflight validation against template manifest & user inputs
        self.latest_report = PreflightChecker.evaluate(
            layout=None,
            template_manifest=self.template_data,
            role_layers=role_layers,
            role_extents=role_extents,
            metadata=metadata,
            logo_path=self.logo_edit.text().strip() or None,
        )

        score = self.latest_report.score
        if self.latest_report.passed:
            self.pf_status_lbl.setText(f"✓ Cartographic Preflight Passed ({score}%)")
            self.pf_status_lbl.setStyleSheet(f"color: {QGISTheme.COLOR_PASS}; font-size: 11pt; font-weight: bold;")
        else:
            self.pf_status_lbl.setText(f"⛔ Preflight Blockers Present ({score}%)")
            self.pf_status_lbl.setStyleSheet(f"color: {QGISTheme.COLOR_BLOCK}; font-size: 11pt; font-weight: bold;")

    def _show_preflight_details(self):
        if hasattr(self, "latest_report"):
            dlg = PreflightDialog(self.latest_report, self)
            dlg.exec()

    def _generate_layout(self):
        self._run_live_preflight()
        if self.latest_report.has_blockers:
            reply = QMessageBox.warning(
                self,
                "Preflight Blockers",
                "The layout contains critical cartographic blockers.\n"
                "Do you still want to generate the layout?",
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
            )
            if reply != QMessageBox.StandardButton.Yes:
                return

        role_layers, role_extents = self._collect_role_layers_and_extents()
        metadata = {
            "title": self.title_edit.text().strip(),
            "subtitle": self.subtitle_edit.text().strip(),
            "source": self.source_edit.text().strip(),
            "author": self.author_edit.text().strip(),
            "organization": self.org_edit.text().strip(),
            "date": self.date_edit.text().strip(),
            "crs": self.crs_edit.text().strip(),
        }

        legend_cfg = {
            "title": "Legend",
            "columns": self.leg_cols.value(),
            "filter_by_map": self.leg_filter_check.isChecked(),
        } if self.leg_check.isChecked() else None

        scale_cfg = {
            "units": self.sb_units.currentData(),
            "segments": 2,
        } if self.sb_check.isChecked() else None

        qpt_path = self.template_data.get("qpt_abs_path")
        name = self.layout_name_edit.text().strip() or self.template_data.get("display_name")

        layout, err = LayoutFactory.create_layout_from_template(
            qpt_path=qpt_path,
            layout_name=name,
            role_layers=role_layers,
            role_extents=role_extents,
            metadata=metadata,
            legend_config=legend_cfg,
            scalebar_config=scale_cfg,
            logo_path=self.logo_edit.text().strip() or None,
            project=QgsProject.instance(),
        )

        if not layout:
            QMessageBox.critical(self, "Generation Failed", f"Could not create layout:\n{err}")
            return

        # Record template usage
        self.settings.record_used_template(self.template_data["id"])

        # Open in layout designer if requested and iface is available
        if self.open_designer_check.isChecked() and self.iface:
            try:
                self.iface.openLayoutDesigner(layout)
            except Exception:
                pass

        QMessageBox.information(
            self,
            "Layout Created",
            f"Layout '{layout.name()}' was successfully created in your project!",
        )
        self.layoutCreated.emit(layout)
        self.accept()
