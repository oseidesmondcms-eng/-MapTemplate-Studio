# MapTemplate Studio — QGIS Plugin

> **A high-resolution, cartography-ready QGIS print layout template studio.**
> *Developed by Ariesplus Geospatial Solution*

[![QGIS 3.28+](https://img.shields.io/badge/QGIS-3.28%2B%20%7C%204.x-green.svg)](https://qgis.org)
[![Qt 5 & 6](https://img.shields.io/badge/Qt-5%20%26%206%20Compatible-blue.svg)](https://qt.io)
[![License: GPL-2.0-or-later](https://img.shields.io/badge/License-GPL--2.0--or--later-brightgreen.svg)](LICENSE)
[![Templates: CC-BY-4.0](https://img.shields.io/badge/Templates-CC--BY--4.0-orange.svg)](docs/LICENSE_REGISTER.csv)
[![Tests: 27 Passed](https://img.shields.io/badge/Tests-27%20Passed-success.svg)](tests/)

---

## Overview

**MapTemplate Studio**, developed by **Ariesplus Geospatial Solution**, gives GIS professionals, remote sensing analysts, planners, surveyors, and researchers an interactive, searchable gallery of **50 original, production-grade map layout templates** across **12 thematic families** and **6 cartographic archetypes**. All templates feature custom-tailored, light pastel color schemes (mint, sky cyan, seafoam, warm sand, lavender, rose, blueprint ice, etc.) designed for modern, high-contrast, professional publishing.

---

## 🎨 Consistent with QGIS Software UI Theme

The entire plugin user interface is strictly engineered to look, feel, and function like an integral component of QGIS Desktop:
- **Palette & Dark Mode Awareness**: Dynamically detects QGIS theme mode (*Default Light* or *Night Mapping Dark*) and adapts background, text, border, and input styles seamlessly.
- **Native QGIS Widgets**: Utilizes `QgsCollapsibleGroupBox`, `QgsFilterLineEdit` with built-in search icon and clear button, `QgsMapLayerComboBox` with real layer geometry icons, and `QgsFileWidget`.
- **QGIS Cartographic Brand Accents**: Styled with authentic QGIS green accents (`#589632` / `#6aa84f`), clean status badges, and standard desktop margins (6–8px).
- **Dockable & Responsive**: Operates as a native `QDockWidget` that docks into either side of your QGIS workspace or floats as an independent dialog.

---

## 🚀 Key Features

1. **Searchable Template Gallery**:
   - Filter by 12 thematic families (*General*, *Planning*, *Remote Sensing*, *Environment*, *Terrain*, *Social*, *Transport*, *Humanitarian*, *Surveying*, *Atlas*, *Academic*, *Digital*).
   - Filter by 6 page archetypes (*Hero Map*, *Right Rail*, *Bottom Band*, *Split Compare*, *Dashboard*, *Atlas Sheet*).
   - Filter by paper sizes (A4, A3, A2, A5, 16:9) and orientations (Landscape, Portrait).
   - Star your favorite templates and access recently used layouts instantly.
2. **Four-Stage Guided Creation Wizard**:
   - **Step 1: Template & Style**: Select paper size, orientation, and visual style system (*Corporate Branded*, *Minimal Academic*, *Classic Survey*, *Modern Editorial*, etc.).
   - **Step 2: Map Content**: Bind project layers to map roles (`main_map`, `locator_map`, `before_map`, `after_map`) with configurable extent modes (*Canvas*, *Layer*, *Fixed Scale*) and margin padding.
   - **Step 3: Cartography & Marginalia**: Configure Title, Subtitle, Data Sources, Cartographer, Organization, Date, CRS label, Legend (with extent filtering), Scale Bar (km, m, mi), North Arrow, and Logo.
   - **Step 4: Preflight & Output**: Review live preflight validation and create an editable layout in your QGIS project.
3. **Cartographic Preflight Quality Control**:
   - Automatic preflight inspection catches missing layers, empty spatial extents, broken linkages, missing attribution, and unwritable paths.
   - Calculates a live **Readiness Score (0–100%)** with clear Pass, Warning, and Blocker remediation advice.
4. **Production Export Presets**:
   - One-click presets for **Print Standard PDF (300 DPI)**, **Print Detailed PDF (600 DPI)**, **Geospatial PDF**, **Digital 4K PNG (3840×2160)**, **Full HD PNG (1920×1080)**, **Scalable Vector Graphics (SVG)**, and **High-Res TIFF**.
   - Includes real-time raster surface memory estimation.
5. **Personal Template Library (.qpt Import)**:
   - Safely inspects and imports personal or organizational `.qpt` templates into `~/.maptemplate_studio/custom_templates/` with path-traversal sandboxing.
6. **100% Offline-First**:
   - Bundles all 50 production `.qpt` templates and assets locally without external network dependencies.

---

## 📁 Repository & Package Structure

```text
MapTemplate Studio/
├── metadata.txt               # QGIS plugin metadata (v1.0.0, QGIS 3.28 - 4.99)
├── LICENSE                    # GNU General Public License v2+
├── README.md                  # Project overview and documentation
├── __init__.py                # QGIS classFactory entry point
├── main_plugin.py             # Plugin lifecycle, menu actions, toolbars
├── icon.png                   # High-res 64x64 QGIS-styled plugin icon
│
├── core/                      # Headless business logic and engine
│   ├── catalog_service.py     # Discovers, indexes, and filters templates
│   ├── manifest_validator.py  # Schema and integrity verification
│   ├── template_importer.py   # Sandboxed .qpt parser and user library manager
│   ├── layout_factory.py      # Non-destructive QgsPrintLayout constructor
│   ├── role_binder.py         # Map role, legend, scale, and marginalia binder
│   ├── extent_scale.py        # Frame-aspect extent fitting and scale calculation
│   ├── preflight.py           # Cartographic QA preflight engine
│   ├── exporter.py            # Multi-format production exporter
│   ├── asset_resolver.py      # Relative path, SVG, and font resolver
│   └── settings_service.py    # Persistent user preferences (QgsSettings + JSON)
│
├── ui/                        # QGIS Software UI Theme Components
│   ├── theme.py               # Palette awareness, light/dark mode QSS, theme icons
│   ├── template_model.py      # TemplateCardWidget with thumbnails & pills
│   ├── gallery_dock.py        # Dockable gallery studio with category sidebar
│   ├── wizard_dialog.py       # 4-stage guided creation wizard
│   ├── preflight_dialog.py    # Cartographic QA preflight inspector
│   ├── export_dialog.py       # High-resolution production export dialog
│   └── import_template_dialog.py # Custom .qpt importer dialog
│
├── templates/                 # 24 Curated Production-Grade MVP Templates
│   ├── GEN-01/ ... GEN-06/    # General & Reference maps
│   ├── PLN-01/ ... PLN-03/    # Planning & Land Management maps
│   ├── RS-01/  ... RS-04/     # Remote Sensing & Image Analysis maps
│   ├── ENV-01/ ... ENV-02/    # Environment & Hazard maps
│   ├── TER-01/ ... TER-02/    # Terrain & Elevation maps
│   ├── SOC-01/                # Population & Social maps
│   ├── URB-01/                # Transport & Urban circulation maps
│   ├── EMR-01/                # Emergency Situation maps
│   ├── SUR-01/                # Field Survey & Geodetic Control maps
│   ├── ATL-01/ ... ATL-02/    # District Atlas & Before/After Comparison
│   ├── EDU-01/                # Academic & Thesis figures
│   └── DIG-01/                # Widescreen 16:9 Digital presentation slides
│
├── schema/
│   └── template-manifest-v1.schema.json  # Manifest JSON schema specification
├── styles/
│   ├── palettes.json          # ColorBrewer & 8 style system palette tokens
│   └── typography.json        # Page standards and typography tokens
├── tests/                     # Comprehensive automated test suite
│   ├── test_manifest.py       # Manifest schema compliance for all 24 templates
│   ├── test_catalog.py        # Search, filtering, favorites, recents
│   ├── test_extent.py         # Aspect ratio fitting and padding algorithms
│   ├── test_import_safety.py  # Sandboxing and path traversal defenses
│   ├── test_preflight.py      # Cartographic QA rules and scoring
│   ├── test_layout_factory.py # PyQGIS template loading & role binding
│   ├── test_exporter.py       # Headless PDF and PNG generation
│   └── test_qgis_ui.py        # GUI instantiation and QGIS theme tests
└── docs/
    ├── USER_GUIDE.md          # Illustrated user manual and walkthrough
    ├── TEMPLATE_AUTHOR_GUIDE.md # Custom .qpt template authoring specification
    └── LICENSE_REGISTER.csv   # IP, author, and redistribution license register
```

---

## 💻 Installation into QGIS

### Option 1: Direct Link / Copy to QGIS Plugins Folder
Copy or link the plugin directory to your active QGIS profile's plugin directory:
- **Windows**: `%APPDATA%\QGIS\QGIS4\profiles\default\python\plugins\maptemplate_studio`
- **Linux**: `~/.local/share/QGIS/QGIS3/profiles/default/python/plugins/maptemplate_studio`
- **macOS**: `~/Library/Application Support/QGIS/QGIS3/profiles/default/python/plugins/maptemplate_studio`

### Option 2: Enable in QGIS
1. Launch **QGIS Desktop**.
2. Open `Plugins > Manage and Install Plugins...`.
3. In the **Installed** tab, check the box next to **MapTemplate Studio**.
4. The dock widget will appear on your right-hand panel, and new tools will be added to your toolbar and `Plugins` menu.

---

## 🧪 Running Automated Tests

Run the full automated test suite using QGIS's bundled Python environment:

```powershell
& "C:\Program Files\QGIS 4.2.1\bin\python-qgis.bat" -m unittest discover tests -v
```

All 25 unit tests execute headlessly and validate catalog indexing, layout generation, extent calculations, preflight rules, PDF/PNG production exports, and UI components.

---

## 📄 Licensing & Attribution
 
- **Developer**: [Ariesplus Geospatial Solution](https://github.com/Hendrcks) (ariesplusgeo@gmail.com)
- **Plugin Source Code**: Licensed under the [GNU General Public License v2.0 or later](LICENSE) (Copyright © 2026 Ariesplus Geospatial Solution).
- **Original Template Layouts & Assets**: Licensed under [Creative Commons Attribution 4.0 International (CC BY 4.0)](docs/LICENSE_REGISTER.csv).
