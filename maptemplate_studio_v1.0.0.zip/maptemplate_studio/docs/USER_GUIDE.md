# MapTemplate Studio — User Guide

**MapTemplate Studio** is a high-resolution, cartography-ready print layout template studio for QGIS Desktop. It replaces tedious manual layout formatting with an interactive gallery of 24 curated templates, automated map-role binding, cartographic preflight quality checks, and production export presets.

---

## 1. Quick Start (Under 60 Seconds)

1. **Open the Studio**: Click the **MapTemplate Studio** icon on the QGIS toolbar, or navigate to `Plugins > MapTemplate Studio > MapTemplate Studio Gallery`.
2. **Choose a Template**: Browse by category (e.g. *General*, *Planning*, *Remote Sensing*, *Terrain*) or use the search box.
3. **Launch the Wizard**: Click **Create Layout...** on the right inspector panel (or double-click the template card).
4. **Bind Map Layers & Extent**: In Step 2, assign your project layers to the map viewports and choose an extent fit mode (*Current Canvas*, *Layer Extent*, or *Fixed Scale*).
5. **Set Marginalia**: In Step 3, enter your Map Title, Subtitle, Data Sources, and Author/Organization.
6. **Preflight & Generate**: Review the automatic cartographic preflight score in Step 4, then click **Generate Layout**.
7. Your new editable layout opens immediately in the native **QGIS Layout Designer**!

---

## 2. Key Features

### 2.1 Searchable Template Gallery
- **12 Thematic Families**:
  - *General & Reference* (GEN-01, GEN-02, GEN-03, GEN-04, GEN-06)
  - *Planning & Land Management* (PLN-01, PLN-02, PLN-03)
  - *Remote Sensing & Image Analysis* (RS-01, RS-02, RS-03, RS-04)
  - *Environment & Hazards* (ENV-01, ENV-02)
  - *Terrain, Geology & Hydrography* (TER-01, TER-02)
  - *Population & Social* (SOC-01)
  - *Transport, Cities & Utilities* (URB-01)
  - *Humanitarian & Emergency* (EMR-01)
  - *Surveying & Engineering* (SUR-01)
  - *Atlas & Map Series* (ATL-01, ATL-02)
  - *Academic & Educational* (EDU-01)
  - *Digital & Social* (DIG-01)
- **Six Cartographic Archetypes**:
  - **Hero Map**: Dominant spatial view (70–85% page coverage) with clean caption.
  - **Right Rail**: Map viewport on left with indicator sidebar, locator inset, and legend on right.
  - **Bottom Band**: Wide landscape map above with full-width multi-column title, legend, scale, and technical credits below.
  - **Split Compare**: Synchronized twin map viewports for before/after and multi-temporal change detection.
  - **Dashboard**: Multi-panel analytical layout with KPIs and callout cards.
  - **Atlas Sheet**: Automated map series layout with coverage page indexing and dynamic titles.
- **Favorites & Recent**: Star frequently used templates for one-click access.

---

### 2.2 Four-Stage Guided Wizard

- **Step 1: Template & Format**: Confirm paper size (A4, A3, A2, A5, 16:9), orientation (Landscape, Portrait), and choose from 8 visual style systems (*Corporate Branded*, *Minimal Academic*, *Classic Survey*, *Modern Editorial*, *Humanitarian Neutral*, *Government Formal*, *Topographic Heritage*, *Dark Digital*).
- **Step 2: Map Content**: Assign project layers to required and optional roles (`main_map`, `locator_map`, `before_map`, `after_map`). Configure margin padding (0–50%).
- **Step 3: Cartography & Marginalia**: Configure Title, Subtitle, Data Sources, Cartographer, Organization, Date, and auto-detected CRS. Enable/disable legend with automatic extent filtering, configure scale bar units (km, m, mi), and attach an institutional logo.
- **Step 4: Review & Generate**: Run live preflight inspection, assign a conflict-free layout name, and open in the QGIS Layout Designer.

---

### 2.3 Cartographic Preflight Quality Control

MapTemplate Studio automatically inspects your map before production to prevent cartographic errors:
- **Blockers (⛔)**:
  - Missing layers for required map viewports.
  - Corrupt geometry or empty spatial bounds.
  - Non-existent or unwritable export directories.
- **Warnings (⚠)**:
  - Generic or empty title ("Untitled Map").
  - Missing data source attribution or provenance.
  - Missing author / organization credits.
  - Missing external logo files.
- **Readiness Score (0–100%)**: Clear visual scoring ensuring publication readiness.

---

### 2.4 Production Export Presets

Export your layouts in high resolution with one click:
| Preset | Format | DPI | Typical Application |
|---|---|---|---|
| **Print Standard** | PDF | 300 | High-quality reports and printed sheets with vector line work. |
| **Print Detailed** | PDF | 600 | Large-format contour and cadastral survey printing. |
| **Geospatial PDF** | PDF | 300 | Geo-registered PDF with coordinates for Adobe Acrobat / Avenza. |
| **Digital 4K** | PNG | 300 | 3840 × 2160 pixels for 16:9 widescreen presentations and digital displays. |
| **Full HD** | PNG | 150 | 1920 × 1080 pixels for web and email briefings. |
| **Draft Preview** | PNG | 150 | Fast proofing and internal review. |
| **Scalable Vector** | SVG | 300 | Editing in Adobe Illustrator, Inkscape, or CorelDRAW. |
| **High-Res TIFF** | TIFF | 300 | Uncompressed raster archive format. |

---

### 2.5 Personal Template Library (.qpt Import)

Import your organization's custom `.qpt` files:
1. Click **＋ Import** on the studio toolbar.
2. Select your `.qpt` file.
3. MapTemplate Studio automatically inspects the layout (detecting maps, labels, legends, and scalebars).
4. Enter metadata (name, family, archetype) and click **Import Template**.
5. The template is stored safely in your user profile directory (`~/.maptemplate_studio/custom_templates/`) without modifying the plugin installation.
